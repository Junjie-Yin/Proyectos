package CITIM21_09;

import CITIM21_09.controller.SesionControlador;

/**
 * Hello world!
 */
public class App {

    public static void main(String[] args) {

        //prueba de inicio

        //JugadorVista jugadorVista=new JugadorVista();
        //Autenticacion autenticacion=new Autenticacion();

        //SesionControlador sesionControlador=new SesionControlador(jugadorVista);
        //sesionControlador.login();
        //sesionControlador.registrar("Admin","Admin@alumnos.upm.es");

        //prueba de partida
        /*
        Algoritmo algoritmo=new NormalAlgoritmo();
        Scanner scanner=new Scanner(System.in);
        ControladorPartida controladorPartida=ControladorPartida.getInstance(scanner);

        //Maquina maquina=new Maquina("Maquina", TDificultad.FACIL,algoritmo );
        JugadorHumano jugador=new JugadorHumano("Juan","juan@alumnos.upm.es");

        controladorPartida.crearPartida(jugador,jugador.getNewPuntuacion(12),jugador.getNewMovimientos(12));
        */


        //Jugador jugador= jugadorHumano;

        //CJugador cJugador=new CJugador();
        //JugadorHumano a=new JugadorHumano("Juan","juan@alumnos.upm.es","1235123");
        //cJugador.crearJugador(a);
        //cJugador.guardarJugadoresEnArchivo();

        //
        //ed745e64aa689ed205323165d424cc7e juan@alumnos.upm.es
        //System.out.println(ExternalLDAP.LoginLDAP());



        /*
        List<IPuntuacion> puntuaciones=new ArrayList<>();
        puntuaciones.add(new Puntuacion(1, 120));
        puntuaciones.add(new Puntuacion(2, 300));
        puntuaciones.add(new Puntuacion(4, 12230));
        puntuaciones.add(new Puntuacion(6, 30230));
        puntuaciones.add(new Puntuacion(7, 1220));
        puntuaciones.add(new Puntuacion(8, 3100));
        puntuaciones.add(new Puntuacion(9, 1220));
        puntuaciones.add(new Puntuacion(10, 3050));

        //Jugador jugador=new JugadorHumano("Juan","ed745e64aa689ed205323165d424cc7e");

        //ADMIN Precargado  Admin@upm.es 12345
        Jugador admin= new Admin("DonJuan","bdf6f39b92f858cef65514e664555e09");

        JugadorPersistencia persistencia=new JugadorPersistencia();
        persistencia.guardarPuntuacionesDeUnJugador("DonJuan",puntuaciones);*/

        SesionControlador.getInstance().start();

    }
}
